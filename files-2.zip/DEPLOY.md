# OakFIN — Website Deployment Guide

Everything in this folder is ready to go live. Follow the steps below in order. No coding required — the whole site is a single self-contained `index.html` plus image and SEO files.

---

## What's in this folder

| File | What it is |
|------|-----------|
| `index.html` | The complete website — all design, content and the brief form |
| `og-image.png` | The preview image shown when the site is shared on LinkedIn/Slack/WhatsApp |
| `favicon.ico` / `favicon-*.png` / `favicon.svg` | The little icon shown in browser tabs |
| `apple-touch-icon.png` | The icon used when someone saves the site to an iPhone home screen |
| `sitemap.xml` | Tells Google which pages exist |
| `robots.txt` | Tells search engines (and AI crawlers) they're welcome to index the site |

**Important:** keep every file in the same folder, with these exact names. The site references them by name.

---

## Step 1 — Connect the brief form (5 minutes)

The contact form needs a free Formspree account to deliver submissions to Nicky's inbox. Until this is done, the form will look right but won't actually send.

1. Go to **formspree.io** and sign up (free plan = 50 submissions/month).
2. Click **+ New Form**, name it `OakFIN Brief`, and set the send-to address to **nicky@oakfinltd.com**.
3. Copy the form's endpoint — it looks like `https://formspree.io/f/abcdwxyz`.
4. Open `index.html` in any text editor (even Notepad). Use Find to locate:
   ```
   const FORMSPREE_ENDPOINT = 'https://formspree.io/f/YOUR_FORM_ID';
   ```
5. Replace `YOUR_FORM_ID` with your real ID and save. Done.

Send yourself a test brief once it's live to confirm it arrives.

---

## Step 2 — Put the site online

Pick whichever is easiest. All three are free to start and take minutes.

### Option A — Netlify (easiest, recommended)
1. Go to **netlify.com** and sign up.
2. Drag this entire folder onto the Netlify dashboard ("deploy manually").
3. The site is instantly live on a `something.netlify.app` address.
4. In Site settings → Domain management, add **oakfinltd.com** and follow the DNS steps.

### Option B — Cloudflare Pages
Similar drag-and-drop deploy at **pages.cloudflare.com**, with excellent speed and free SSL.

### Option C — Keep GoDaddy hosting
If you'd rather stay with GoDaddy, ask their support to replace the current "coming soon" page with these files via their File Manager or FTP. Upload everything in this folder to the public root (often called `public_html`).

---

## Step 3 — Point the domain

Wherever you host, you'll connect **oakfinltd.com** by updating the domain's DNS records. Netlify and Cloudflare both walk you through this with copy-paste values. SSL (the padlock / https) is automatic and free on all three options above.

---

## Step 4 — Tell Google about the site (10 minutes)

This is what gets OakFIN found in search.

1. Go to **search.google.com/search-console** and add **oakfinltd.com** as a property.
2. Verify ownership (usually a DNS record or a file upload — Search Console walks you through it).
3. Once verified, go to **Sitemaps** in the left menu and submit:
   ```
   sitemap.xml
   ```
4. Repeat the same submission at **bing.com/webmasters** for Bing and Copilot visibility.

---

## Step 5 — Connect analytics (optional but recommended)

To see who's visiting and where they come from:

1. Create a free **Google Analytics 4** property at **analytics.google.com**.
2. Copy your Measurement ID (looks like `G-XXXXXXXXXX`).
3. In `index.html`, just before `</head>`, paste the GA4 snippet Google gives you.

---

## After you're live — quick checklist

- [ ] Form endpoint connected and test brief received
- [ ] Site loads at https://oakfinltd.com with the padlock showing
- [ ] Share the link in a LinkedIn message to yourself — confirm the preview image appears
- [ ] Sitemap submitted to Google Search Console
- [ ] Update the LinkedIn company page "Website" link to the new site

---

## A note on the OG preview image

`og-image.png` controls how the site looks when shared. It's already referenced correctly. If you ever want to change it, replace the file but keep the name `og-image.png` and the dimensions **1200 × 630 pixels**.

---

Questions on any step — come back and I'll walk you through it.

---

## ✦ NEW — Additional pages added (June 2026)

The site now includes **six additional pages** beyond the homepage. These are the
foundation of OakFIN's search visibility and lead capture.

### SEO landing pages (5)

Each targets a specific search term recruiters' clients actually type into Google:

| Folder | Targets the search | Words |
|--------|-------------------|-------|
| `fintech-recruitment-agency/` | "fintech recruitment agency" | ~1,000 |
| `saas-sales-recruitment/` | "SaaS sales recruitment" | ~800 |
| `customer-success-recruitment/` | "customer success recruitment" | ~750 |
| `private-markets-saas-recruitment/` | "private markets software recruitment" | ~750 |
| `fintech-recruitment-london/` | "fintech recruitment London" | ~750 |

### Candidate registration page (1)

`candidates/` — a structured registration form that captures sector, role, location,
salary and availability, so candidate details arrive ready to segment instead of as
free-text emails. **It uses the same Formspree setup as the brief form** — once Step 1
is done, paste the same endpoint into `candidates/index.html` too (search for
`FORMSPREE_ENDPOINT`). You can point it at the same Formspree form or a separate one
named "OakFIN Candidates" if you'd prefer registrations and briefs kept apart.

### One shared stylesheet

`oakfin.css` holds the design system (colours, fonts, components) for all the
sub-pages. **Keep it in the root folder** — every sub-page links to it as `/oakfin.css`.
The homepage keeps its styles inline, so it works even on its own.

### Folder structure when you upload

```
/                                 → index.html (homepage)
/oakfin.css                       → shared styles for sub-pages
/candidates/                      → candidate registration
/fintech-recruitment-agency/      → SEO page
/saas-sales-recruitment/          → SEO page
/customer-success-recruitment/    → SEO page
/private-markets-saas-recruitment/→ SEO page
/fintech-recruitment-london/      → SEO page
+ all favicon / og-image / sitemap / robots files in root
```

Upload the **whole folder** as-is. The links between pages use clean paths
(`/candidates/`, `/saas-sales-recruitment/`) that work automatically on Netlify,
Vercel, Cloudflare Pages and most static hosts. On a traditional host, the folder
structure produces the same clean URLs because each page is named `index.html`
inside its own folder.

### Two-minute activation checklist for the new pages

- [ ] Paste your Formspree endpoint into `candidates/index.html` (same as the homepage)
- [ ] Confirm all 6 new pages load (e.g. oakfinltd.com/fintech-recruitment-agency/)
- [ ] Re-submit `sitemap.xml` in Google Search Console (now lists all 7 pages)
- [ ] Send a test candidate registration to confirm it arrives

